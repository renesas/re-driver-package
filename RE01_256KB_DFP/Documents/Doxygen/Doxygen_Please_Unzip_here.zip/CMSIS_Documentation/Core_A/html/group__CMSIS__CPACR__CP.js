var group__CMSIS__CPACR__CP =
[
    [ "CPACR_CP_FA", "group__CMSIS__CPACR__CP.html#gaeaa29f06a74fadc7245d6bd183bad11b", null ],
    [ "CPACR_CP_NA", "group__CMSIS__CPACR__CP.html#gabd03f590b34b809438eaa3df4af2e7db", null ],
    [ "CPACR_CP_PL1", "group__CMSIS__CPACR__CP.html#ga8602342c0bad80f3a36d3bdee7418a46", null ]
];