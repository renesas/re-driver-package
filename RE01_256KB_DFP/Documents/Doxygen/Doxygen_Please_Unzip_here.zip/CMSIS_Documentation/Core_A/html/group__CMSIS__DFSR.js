var group__CMSIS__DFSR =
[
    [ "ACTLR Bits", "group__CMSIS__DFSR__BITS.html", "group__CMSIS__DFSR__BITS" ],
    [ "DFSR_Type", "unionDFSR__Type.html", [
      [ "CM", "unionDFSR__Type.html#a38562a26cc210ea4c39c6b951c4a5b62", null ],
      [ "Domain", "unionDFSR__Type.html#a38982c7088a4069f8a4b347f5eb400e9", null ],
      [ "ExT", "unionDFSR__Type.html#aede34079d030df1977646c155a90f445", null ],
      [ "FS0", "unionDFSR__Type.html#af29edf59ecfd29848b69e2bbfb7f3082", null ],
      [ "FS1", "unionDFSR__Type.html#a869658f432d5e213b8cd55e8e58d1f56", null ],
      [ "l", "unionDFSR__Type.html#a583e3138696be655c46f297e083ece52", null ],
      [ "LPAE", "unionDFSR__Type.html#add7c7800b87cabdb4a9ecdf41e4469a7", null ],
      [ "s", "unionDFSR__Type.html#a54c2eb668436a0f15d781265ceaa8c58", null ],
      [ "STATUS", "unionDFSR__Type.html#a4cb3ba7b8c8075bfbff792b7e5b88103", null ],
      [ "w", "unionDFSR__Type.html#ad827a36e38ce2dee796835122ae95dd2", null ],
      [ "WnR", "unionDFSR__Type.html#a0512860c27723cd35f0abdaa68be9935", null ]
    ] ],
    [ "__get_DFSR", "group__CMSIS__DFSR.html#ga9897e96a6ccb50199d4968fd45ab7962", null ],
    [ "__set_DFSR", "group__CMSIS__DFSR.html#ga824a3e4ae371ef38641375f9fa4cc29c", null ]
];