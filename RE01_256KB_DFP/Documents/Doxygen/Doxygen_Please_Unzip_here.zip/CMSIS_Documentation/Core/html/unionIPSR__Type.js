var unionIPSR__Type =
[
    [ "_reserved0", "unionIPSR__Type.html#ad2eb0a06de4f03f58874a727716aa9aa", null ],
    [ "b", "unionIPSR__Type.html#add0d6497bd50c25569ea22b48a03ec50", null ],
    [ "ISR", "unionIPSR__Type.html#ab46e5f1b2f4d17cfb9aca4fffcbb2fa5", null ],
    [ "w", "unionIPSR__Type.html#a4adca999d3a0bc1ae682d73ea7cfa879", null ]
];