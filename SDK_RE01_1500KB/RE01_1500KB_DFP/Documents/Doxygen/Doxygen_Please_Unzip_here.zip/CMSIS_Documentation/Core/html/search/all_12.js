var searchData=
[
  ['u16',['u16',['../structITM__Type.html#a962a970dfd286cad7f8a8577e87d4ad3',1,'ITM_Type']]],
  ['u32',['u32',['../structITM__Type.html#a5834885903a557674f078f3b71fa8bc8',1,'ITM_Type']]],
  ['u8',['u8',['../structITM__Type.html#ae773bf9f9dac64e6c28b14aa39f74275',1,'ITM_Type']]],
  ['usagefault_5firqn',['UsageFault_IRQn',['../group__NVIC__gr.html#gga7e1129cd8a196f4284d41db3e82ad5c8a6895237c9443601ac832efa635dd8bbf',1,'Ref_NVIC.txt']]],
  ['using_2etxt',['Using.txt',['../Using_8txt.html',1,'']]],
  ['using_20cmsis_20with_20generic_20arm_20processors',['Using CMSIS with generic Arm Processors',['../using_ARM_pg.html',1,'using_pg']]],
  ['using_20cmsis_20in_20embedded_20applications',['Using CMSIS in Embedded Applications',['../using_pg.html',1,'']]],
  ['using_20trustzone_20for_20armv8_2dm',['Using TrustZone for Armv8-M',['../using_TrustZone_pg.html',1,'']]],
  ['using_20interrupt_20vector_20remap',['Using Interrupt Vector Remap',['../using_VTOR_pg.html',1,'using_pg']]],
  ['usingtrustzone_2etxt',['UsingTrustZone.txt',['../UsingTrustZone_8txt.html',1,'']]]
];
