var searchData=
[
  ['trustzone_20for_20armv8_2dm',['TrustZone for Armv8-M',['../group__trustzone__functions.html',1,'']]]
];
